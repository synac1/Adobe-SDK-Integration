# Covid-Challenge
## Yanilda Peralta
## Topcoder username:  yanilda20

### For guideline for CLI program check: guideline-cli.md
### For guideline for Integration of Adobe DC View SDK: guideline-web.md
### For video: [video](https://youtu.be/UbaQnxPQfko)