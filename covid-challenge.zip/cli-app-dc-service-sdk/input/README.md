# About these files
## For this project I decided to download some free education website templates under the GNU  [Free CSS.com](
https://www.free-css.com/)
