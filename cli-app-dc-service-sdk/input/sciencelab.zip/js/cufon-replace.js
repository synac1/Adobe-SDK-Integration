Cufon.replace('#menu li a, #menu_active, h1', { fontFamily: 'Myriad Pro', hover:true });

